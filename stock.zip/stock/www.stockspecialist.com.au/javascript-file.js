$.fn.editable.defaults.mode = 'inline';
$('.edit_text').editable({
    success : function(k, val)
    {
        
      var i = $(".edit_text").index(this);
        $('.name-list p:eq('+ i +')').html(val);
        
    }
});
//var title = $('.edit_text').editable('getValue');